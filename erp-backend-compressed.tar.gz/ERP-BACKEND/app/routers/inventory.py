from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, ConfigDict
from typing import Optional, List
from datetime import datetime, timezone
from decimal import Decimal

from app.database import get_db
from app.models import Product, InventoryMovement
from app.auth import get_current_user
from app.services.activity_log import log_activity

router = APIRouter()

class ProductCreate(BaseModel):
    sku: str
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    unit_price: float = 0
    cost_price: Optional[float] = None
    quantity_in_stock: int = 0
    reorder_level: int = 10
    reorder_quantity: int = 50
    supplier: Optional[str] = None
    supplier_contact: Optional[str] = None
    status: str = "active"
    barcode: Optional[str] = None
    weight: Optional[float] = None
    dimensions: Optional[str] = None

class ProductResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    sku: str
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    unit_price: float
    cost_price: Optional[float] = None
    quantity_in_stock: int
    reorder_level: int
    reorder_quantity: int
    supplier: Optional[str] = None
    supplier_contact: Optional[str] = None
    status: str
    barcode: Optional[str] = None
    weight: Optional[float] = None
    dimensions: Optional[str] = None
    created_at: datetime
    updated_at: datetime

class MovementCreate(BaseModel):
    product_id: int
    movement_type: str
    quantity: int
    unit_cost: Optional[float] = None
    reference: Optional[str] = None
    notes: Optional[str] = None

class MovementResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    product_id: int
    movement_type: str
    quantity: int
    unit_cost: Optional[float] = None
    reference: Optional[str] = None
    notes: Optional[str] = None
    created_by: Optional[int] = None
    created_at: datetime

@router.post("/products", response_model=ProductResponse)
def create_product(data: ProductCreate, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    """
    Create a product and record its creation activity.
    
    Parameters:
        data (ProductCreate): Product details, including its SKU.
        current_user: Authenticated user creating the product.
    
    Returns:
        Product: The newly created product.
    """
    existing = db.query(Product).filter(Product.sku == data.sku).first()
    if existing:
        raise HTTPException(status_code=400, detail="SKU already exists")

    product = Product(**data.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    log_activity(db, user_id=current_user.id, action="product_created", entity_type="product", entity_id=product.id)
    return product

@router.get("/products", response_model=List[ProductResponse])
def list_products(
    category: Optional[str] = None,
    status: Optional[str] = None,
    low_stock: bool = False,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    List products with optional category, status, low-stock, and name filters.
    
    Parameters:
        category (Optional[str]): Restrict results to a product category.
        status (Optional[str]): Restrict results to a product status.
        low_stock (bool): Restrict results to products at or below their reorder level.
        search (Optional[str]): Restrict results to products whose names contain this text.
    
    Returns:
        list[Product]: Matching products.
    """
    query = db.query(Product)
    if category:
        query = query.filter(Product.category == category)
    if status:
        query = query.filter(Product.status == status)
    if low_stock:
        query = query.filter(Product.quantity_in_stock <= Product.reorder_level)
    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))
    return query.all()

@router.get("/products/{product_id}", response_model=ProductResponse)
def get_product(product_id: int, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    """
    Retrieve a product by its identifier.
    
    Parameters:
    	product_id (int): The product identifier.
    
    Returns:
    	Product: The matching product record.
    """
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

@router.put("/products/{product_id}", response_model=ProductResponse)
def update_product(product_id: int, data: ProductCreate, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    """
    Update an existing product with the supplied fields.
    
    Parameters:
    	product_id (int): Identifier of the product to update.
    	data (ProductCreate): Product fields and values to apply.
    
    Returns:
    	Product: The updated product.
    
    Raises:
    	HTTPException: If the product does not exist.
    """
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    for key, value in data.model_dump().items():
        setattr(product, key, value)
    product.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(product)
    return product

@router.delete("/products/{product_id}")
def delete_product(product_id: int, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    """
    Delete a product by its identifier.
    
    Parameters:
        product_id (int): Identifier of the product to delete.
    
    Returns:
        dict: Confirmation message indicating that the product was deleted.
    """
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    db.delete(product)
    db.commit()
    return {"message": "Product deleted"}

@router.post("/movements", response_model=MovementResponse)
def create_movement(data: MovementCreate, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    """
    Create an inventory movement and update the associated product's stock.
    
    Parameters:
        data (MovementCreate): Movement details, including the product, movement type, and quantity.
    
    Returns:
        InventoryMovement: The created inventory movement.
    
    Raises:
        HTTPException: If the product does not exist or an outgoing movement exceeds available stock.
    """
    product = db.query(Product).filter(Product.id == data.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    movement = InventoryMovement(**data.model_dump(), created_by=current_user.id)

    # Update stock
    if data.movement_type == "in":
        product.quantity_in_stock += data.quantity
    elif data.movement_type == "out":
        if product.quantity_in_stock < data.quantity:
            raise HTTPException(status_code=400, detail="Insufficient stock")
        product.quantity_in_stock -= data.quantity
    elif data.movement_type == "adjustment":
        product.quantity_in_stock = data.quantity

    product.updated_at = datetime.now(timezone.utc)
    db.add(movement)
    db.commit()
    db.refresh(movement)
    log_activity(db, user_id=current_user.id, action="inventory_moved", entity_type="inventory_movement", entity_id=movement.id)
    return movement

@router.get("/movements", response_model=List[MovementResponse])
def list_movements(product_id: Optional[int] = None, db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    """
    List inventory movements, optionally filtered by product.
    
    Parameters:
        product_id (Optional[int]): Product identifier used to filter the movements.
    
    Returns:
        List[InventoryMovement]: Inventory movements ordered from newest to oldest.
    """
    query = db.query(InventoryMovement)
    if product_id:
        query = query.filter(InventoryMovement.product_id == product_id)
    return query.order_by(InventoryMovement.created_at.desc()).all()

@router.get("/dashboard")
def inventory_dashboard(db: Session = Depends(get_db), current_user = Depends(get_current_user)):
    from sqlalchemy import func
    total_products = db.query(Product).count()
    total_stock_value = db.query(func.sum(Product.quantity_in_stock * Product.unit_price)).scalar() or 0
    low_stock_count = db.query(Product).filter(Product.quantity_in_stock <= Product.reorder_level).count()
    out_of_stock = db.query(Product).filter(Product.quantity_in_stock == 0).count()

    return {
        "total_products": total_products,
        "total_stock_value": float(total_stock_value),
        "low_stock_count": low_stock_count,
        "out_of_stock": out_of_stock,
        "categories": db.query(Product.category, func.count(Product.id)).group_by(Product.category).all()
    }

