---
name: Feature Request
about: Suggest an idea for this project
title: '[FEATURE] '
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Which module**
- [ ] Backend (API)
- [ ] Frontend (Web)
- [ ] Mobile App
- [ ] DevOps/CI-CD
- [ ] Documentation
- [ ] AI/ML Features

**Additional context**
Add any other context or screenshots about the feature request here.
